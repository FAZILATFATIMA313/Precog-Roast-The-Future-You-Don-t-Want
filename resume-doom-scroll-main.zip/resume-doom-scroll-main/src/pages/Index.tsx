import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Upload, Loader2, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

type CareerFate = {
  title: string;
  confidence: number;
  roast: string;
  scenario: string;
  imageUrl?: string;
  skills?: string[];
};

const Index = () => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [prophecy, setProphecy] = useState<CareerFate | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.pdf')) {
      toast.error("Please upload a PDF file");
      return;
    }

    setIsProcessing(true);
    setProphecy(null);

    try {
      // Convert file to base64
      const reader = new FileReader();
      reader.onload = async (e) => {
        const base64 = e.target?.result as string;
        
        // Call edge function to process resume
        const { data, error } = await supabase.functions.invoke('roast-resume', {
          body: { 
            resumeData: base64.split(',')[1], // Remove data:application/pdf;base64, prefix
            fileName: file.name 
          }
        });

        if (error) {
          console.error("Error processing resume:", error);
          toast.error("Failed to process resume. Please try again.");
          setIsProcessing(false);
          return;
        }

        setProphecy(data);
        setIsProcessing(false);
        toast.success("Your future has been revealed...");
      };

      reader.onerror = () => {
        toast.error("Failed to read file");
        setIsProcessing(false);
      };

      reader.readAsDataURL(file);
    } catch (error) {
      console.error("Error:", error);
      toast.error("Something went wrong");
      setIsProcessing(false);
    }
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Animated background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-black to-cyan-900/20 animate-pulse" />
      
      {/* Scanline effect */}
      <div className="scanline absolute inset-0 pointer-events-none" />

      <div className="relative z-10 container mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 
            className="text-6xl md:text-8xl font-bold mb-4 glitch-text text-glow"
            data-text="PRECOG ROAST"
            style={{ fontFamily: 'monospace' }}
          >
            PRECOG ROAST
          </h1>
          <p className="text-xl md:text-2xl text-primary font-mono">
            THE FUTURE YOU DON'T WANT
          </p>
          <div className="mt-4 h-0.5 w-64 mx-auto bg-gradient-to-r from-transparent via-primary to-transparent" />
        </div>

        {/* Main content */}
        <div className="max-w-4xl mx-auto">
          {!prophecy && !isProcessing && (
            <Card className="neon-border bg-card/50 backdrop-blur-sm p-12 text-center">
              <div className="space-y-6">
                <div className="mx-auto w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center">
                  <Sparkles className="w-12 h-12 text-primary" />
                </div>
                
                <h2 className="text-3xl font-bold text-foreground font-mono">
                  UPLOAD YOUR RÉSUMÉ
                </h2>
                
                <p className="text-muted-foreground max-w-md mx-auto font-mono text-sm">
                  Let the AI peer into your professional future. 
                  Warning: What you see cannot be unseen.
                </p>

                <div className="pt-4">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".pdf"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <Button
                    onClick={handleUploadClick}
                    className="bg-primary hover:bg-primary/80 text-primary-foreground font-bold text-lg px-8 py-6 font-mono neon-border"
                    size="lg"
                  >
                    <Upload className="mr-2 h-5 w-5" />
                    INITIATE SCAN
                  </Button>
                </div>

                <div className="text-xs text-muted-foreground font-mono pt-4">
                  [ ACCEPTED FORMAT: PDF ONLY ]
                </div>
              </div>
            </Card>
          )}

          {isProcessing && (
            <Card className="neon-border bg-card/50 backdrop-blur-sm p-12 text-center">
              <div className="space-y-6">
                <Loader2 className="w-16 h-16 animate-spin mx-auto text-primary" />
                <div className="space-y-2">
                  <h3 className="text-2xl font-bold text-foreground font-mono glitch-text" data-text="ANALYZING...">
                    ANALYZING...
                  </h3>
                  <p className="text-muted-foreground font-mono text-sm">
                    [ PARSING CAREER TRAJECTORY ]
                  </p>
                  <p className="text-muted-foreground font-mono text-sm">
                    [ CALCULATING DOOM PROBABILITY ]
                  </p>
                  <p className="text-muted-foreground font-mono text-sm">
                    [ GENERATING PROPHECY ]
                  </p>
                </div>
              </div>
            </Card>
          )}

          {prophecy && (
            <Card className="neon-border bg-card/50 backdrop-blur-sm p-8 space-y-6">
              {/* Career Fate Header */}
              <div className="border-b border-primary/30 pb-6">
                <div className="flex items-center justify-between mb-2">
                  <h2 className="text-3xl font-bold text-primary font-mono glitch-text" data-text={prophecy.title}>
                    {prophecy.title}
                  </h2>
                  <div className="text-right">
                    <div className="text-sm text-muted-foreground font-mono">CONFIDENCE</div>
                    <div className="text-2xl font-bold text-secondary font-mono text-glow">
                      {prophecy.confidence}%
                    </div>
                  </div>
                </div>
              </div>

              {/* Generated Image */}
              {prophecy.imageUrl && (
                <div className="relative neon-border rounded-lg overflow-hidden">
                  <img 
                    src={prophecy.imageUrl} 
                    alt="Your doomed future"
                    className="w-full h-auto"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent pointer-events-none" />
                </div>
              )}

              {/* Extracted Skills */}
              {prophecy.skills && prophecy.skills.length > 0 && (
                <div className="border-b border-primary/30 pb-6">
                  <h3 className="text-lg font-bold text-secondary mb-3 font-mono">
                    [ SKILLS DETECTED ]
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {prophecy.skills.map((skill, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-primary/10 border border-primary/30 text-primary text-sm font-mono rounded-sm neon-border"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Roast Text */}
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-bold text-secondary mb-2 font-mono">
                    [ PROPHECY ]
                  </h3>
                  <p className="text-foreground font-mono text-lg leading-relaxed">
                    {prophecy.roast}
                  </p>
                </div>

                <div>
                  <h3 className="text-lg font-bold text-secondary mb-2 font-mono">
                    [ FUTURE SCENARIO ]
                  </h3>
                  <p className="text-muted-foreground font-mono">
                    {prophecy.scenario}
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-6 border-t border-primary/30 flex gap-4 justify-center">
                <Button
                  onClick={() => {
                    setProphecy(null);
                    if (fileInputRef.current) {
                      fileInputRef.current.value = '';
                    }
                  }}
                  variant="outline"
                  className="neon-border font-mono"
                >
                  SCAN ANOTHER
                </Button>
              </div>
            </Card>
          )}
        </div>

        {/* Footer */}
        <div className="text-center mt-12 text-muted-foreground font-mono text-xs">
          <p>[ POWERED BY AI PROPHECY ENGINE v2.5 ]</p>
          <p className="mt-2">NO REFUNDS. NO EXCEPTIONS. THE FUTURE IS FINAL.</p>
        </div>
      </div>
    </div>
  );
};

export default Index;
